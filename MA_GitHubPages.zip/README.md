# MA Game - GitHub Pages Version
Deploy by pushing these files to a repo and enabling Pages.